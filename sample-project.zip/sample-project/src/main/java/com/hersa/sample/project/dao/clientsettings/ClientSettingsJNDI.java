package com.hersa.sample.project.dao.clientsettings;

public class ClientSettingsJNDI {

}
