package com.hersa.sample.project.test;

public class Triangle {
	
	public void draw() {
		System.out.println("triangle draw");
	}
	
}
