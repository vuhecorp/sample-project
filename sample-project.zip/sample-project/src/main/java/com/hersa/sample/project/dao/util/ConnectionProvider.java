package com.hersa.sample.project.dao.util;

public interface ConnectionProvider {
	
}
