package com.hersa.sample.project.bom.userprofile;

import com.hersa.sample.project.bom.AbstractBaseManager;

public class UserProfileManager extends AbstractBaseManager{
	
}
