package com.hersa.sample.project.bom;

public class Manager {

	public Manager() {
		// TODO Auto-generated constructor stub
	}

}
